package com.example.logger;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



import android.os.Bundle;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    public EditText emailId, passwd;
    Button btnSignUp;
    TextView signIn;

    public  FirebaseAuth firebaseAuth;
    public FirebaseUser currentUser;

    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        firebaseAuth = FirebaseAuth.getInstance();

        emailId = findViewById(R.id.editText);
        passwd = findViewById(R.id.editText2);
        btnSignUp = findViewById(R.id.button);
        signIn = findViewById(R.id.button2);


        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String emailID = emailId.getText().toString();
                String paswd = passwd.getText().toString();
                createAccount(emailID, paswd);
            }
            });

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailID = emailId.getText().toString();
                String paswd = passwd.getText().toString();
                LogIn(emailID, paswd);
            }
        });


             //
   }
    public void LogIn(String i,String p){
        firebaseAuth.signInWithEmailAndPassword(i,p).addOnCompleteListener(this,new OnCompleteListener<AuthResult>(){
            @Override
            public void onComplete(@NonNull Task<AuthResult>task){
                if(task.isSuccessful()){
                    Log.d(TAG, "Success");
                      currentUser=firebaseAuth.getCurrentUser();
                    startActivity(new Intent(MainActivity.this,Menu.class));
                    //finish();
                   // UpdateUI();


                }
            }
        });
    }
    public void createAccount(String i,String p){
        firebaseAuth.createUserWithEmailAndPassword(i, p).addOnCompleteListener(this,  new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()) {
                    Log.d(TAG, "createUserWithEmail: success");
                    currentUser = firebaseAuth.getCurrentUser();
                    ///updateUI(user);
                } else {
                    Log.w(TAG, "failed", task.getException());
                    //Toast.makeText(EmailPasswordActivity.this, "failure", Toast.LENGTH_SHORT).show();
                    //updateUI(null);
                }
            }
        });

    }



}




